<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>tabuada</title>
</head>
<body>
    <?php
    $n = $_POST ["number"];
    for ($i=0; $i<=10; $i++){
        $saida .= "$n x $i = " . ($n * $i) . "<br>";
    }
?>

<p>usuario: <?php echo $saida ?> </p>

</body>
</html>