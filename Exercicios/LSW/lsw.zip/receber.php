<?php 

$number = $_POST ["number"];
$saida = $_POST ["saida"];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<p>usuario: <?php echo $user ?> </p>
<p>senha: <?php echo $pass ?> </p>  
</body>
</html>